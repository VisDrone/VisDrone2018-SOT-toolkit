function trackers = configTrackers()

trackers = {
            struct('name','Staple','namePaper','Staple')
            };
